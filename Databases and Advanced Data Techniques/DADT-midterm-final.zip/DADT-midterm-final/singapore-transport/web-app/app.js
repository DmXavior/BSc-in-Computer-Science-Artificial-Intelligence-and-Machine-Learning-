const express = require('express');
const mysql = require('mysql');

const app = express();
const port = 3000;

// View engine setup
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');

// Static files
app.use(express.static('public'));

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'singapore_transport_db'
});

connection.connect((err) => {
  if (err) {
    console.error('Database connection failed: ' + err.stack);
    console.error('Error details:', err);
    return;
  }
  console.log('Connected to MySQL database successfully!');
});

app.get('/', (req, res) => {
  console.log('Request received for /');
  const queries = [
    'SELECT COUNT(DISTINCT planning_area_id) AS planningAreas FROM `planning_areas`',
    'SELECT SUM(population_count) AS totalPopulation FROM `population_statistics`',
    'SELECT SUM(employee_count) AS totalEmployment FROM `employment_statistics`'
  ];

  const promises = queries.map(query => {
    return new Promise((resolve, reject) => {
      connection.query(query, (err, result) => {
        if (err) {
          return reject(err);
        }
        resolve(result[0]);
      });
    });
  });

  Promise.all(promises)
    .then(results => {
      const stats = {
        planningAreas: results[0].planningAreas,
        totalPopulation: results[1].totalPopulation,
        totalEmployment: results[2].totalEmployment
      };
      res.render('index', { title: 'Home', stats: stats });
    })
    .catch(err => {
      console.error(err);
      res.render('error', { message: 'Error fetching statistics.' });
    });
});

app.get('/employment', (req, res) => {
  console.log('Request received for /employment');
  const query = `
    SELECT pa.planning_area_name, SUM(es.employee_count) as total_employees
    FROM employment_statistics es
    JOIN planning_areas pa ON es.planning_area_id = pa.planning_area_id
    JOIN occupation_categories oc ON es.occupation_id = oc.occupation_id
    WHERE oc.occupation_name = 'Total'
    GROUP BY pa.planning_area_name
    ORDER BY total_employees DESC;
  `;
  connection.query(query, (err, results) => {
    if (err) {
      console.error(err);
      res.render('error', { message: 'Error fetching employment data.' });
      return;
    }

    const employmentData = results.map(row => {
      let center_type = 'Small Center';
      if (row.total_employees > 100000) center_type = 'Major Hub';
      else if (row.total_employees > 50000) center_type = 'Significant Center';
      else if (row.total_employees > 20000) center_type = 'Medium Center';

      return {
        planning_area_name: row.planning_area_name,
        total_employees: row.total_employees,
        employees_thousands: (row.total_employees / 1000).toFixed(1),
        center_type: center_type
      };
    });

    res.render('employment', { title: 'Employment', employmentData: employmentData });
  });
});

app.get('/housing-transport', (req, res) => {
  console.log('Request received for /housing-transport');
  const query = `
    WITH condo_areas AS (
        SELECT
            pa.planning_area_id,
            pa.planning_area_name,
            SUM(CASE WHEN dt.dwelling_type_name = 'Condominiums and Other Apartments'
                THEN ps.population_count ELSE 0 END) as condo_residents,
            SUM(ps.population_count) as total_residents,
            ROUND(SUM(CASE WHEN dt.dwelling_type_name = 'Condominiums and Other Apartments'
                THEN ps.population_count ELSE 0 END) * 100.0 / SUM(ps.population_count), 2) as condo_percentage
        FROM population_statistics ps
        JOIN subzones s ON ps.subzone_id = s.subzone_id
        JOIN planning_areas pa ON s.planning_area_id = pa.planning_area_id
        JOIN dwelling_types dt ON ps.dwelling_type_id = dt.dwelling_type_id
        GROUP BY pa.planning_area_id, pa.planning_area_name
    ),
    transport_summary AS (
        SELECT
            ts.planning_area_id,
            SUM(CASE WHEN tm.transport_mode_name = 'Car Only' THEN ts.resident_count ELSE 0 END) as car_users,
            SUM(CASE WHEN tm.transport_mode_name = 'Total' THEN ts.resident_count ELSE 0 END) as total_commuters
        FROM transportation_statistics ts
        JOIN transportation_modes tm ON ts.transport_mode_id = tm.transport_mode_id
        GROUP BY ts.planning_area_id
    )
    SELECT
        ca.planning_area_name,
        ca.condo_percentage,
        ca.total_residents,
        ts.car_users,
        ROUND(ts.car_users * 100.0 / ts.total_commuters, 2) as car_usage_percentage
    FROM condo_areas ca
    JOIN transport_summary ts ON ca.planning_area_id = ts.planning_area_id
    WHERE ca.total_residents > 0 AND ts.total_commuters > 0
    ORDER BY ca.condo_percentage DESC;
  `;
  connection.query(query, (err, results) => {
    if (err) {
      console.error(err);
      res.render('error', { message: 'Error fetching housing and transport data.' });
      return;
    }
    res.render('housing-transport', { title: 'Housing & Transport', correlationData: results });
  });
});

app.get('/transportation', (req, res) => {
  console.log('Request received for /transportation');
  const query = `
    SELECT pa.planning_area_name, tm.transport_mode_name, ts.resident_count
    FROM transportation_statistics ts
    JOIN planning_areas pa ON ts.planning_area_id = pa.planning_area_id
    JOIN transportation_modes tm ON ts.transport_mode_id = tm.transport_mode_id
    ORDER BY pa.planning_area_name, ts.resident_count DESC;
  `;
  connection.query(query, (err, results) => {
    if (err) {
      console.error(err);
      res.render('error', { message: 'Error fetching transportation data.' });
      return;
    }

    const areaData = {};
    results.forEach(row => {
      if (!areaData[row.planning_area_name]) {
        areaData[row.planning_area_name] = {
          total: 0,
          modes: []
        };
      }
      if (row.transport_mode_name === 'Total') {
        areaData[row.planning_area_name].total = row.resident_count;
      } else {
        areaData[row.planning_area_name].modes.push({
          mode: row.transport_mode_name,
          count: row.resident_count
        });
      }
    });

    for (const area in areaData) {
      areaData[area].modes.forEach(mode => {
        mode.percentage = areaData[area].total ? ((mode.count / areaData[area].total) * 100).toFixed(2) : 0;
      });
    }

    res.render('transportation', { title: 'Transportation', areaData: areaData });
  });
});

app.listen(port, function () {
  console.log('The app is listening at http://localhost:' + port + '.');
});