INSTRUCTIONS 

# To start node server to run web application

1. go to mid-term/singapore-transport/web-app
2. npm install (for all dependencies)
3. use "npm run dev", NOT "node app.js"
4. Should be able to see the web app running on PORT: 3000

# MySQL database

1. go to mid-term/singapore-transport
2. run "mysql"
3. USE "singapore_transport_db"
4. Should be able to access the sql database to see all tables available
