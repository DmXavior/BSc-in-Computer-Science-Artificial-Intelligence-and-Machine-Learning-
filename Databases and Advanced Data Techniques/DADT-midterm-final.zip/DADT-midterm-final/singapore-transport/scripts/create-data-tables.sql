CREATE TABLE planning_areas (
    planning_area_id INT PRIMARY KEY AUTO_INCREMENT,
    planning_area_name VARCHAR(100) NOT NULL UNIQUE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE transportation_modes (
    transport_mode_id INT PRIMARY KEY AUTO_INCREMENT,
    transport_mode_name VARCHAR(150) NOT NULL UNIQUE,
    transport_category VARCHAR(50)
);

CREATE TABLE dwelling_categories (
    category_id INT PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(50) NOT NULL UNIQUE,
    category_description TEXT
);

CREATE TABLE occupation_categories (
    occupation_id INT PRIMARY KEY AUTO_INCREMENT,
    occupation_name VARCHAR(200) NOT NULL UNIQUE,
    occupation_code VARCHAR(10) UNIQUE,
    occupation_level VARCHAR(20)
);

CREATE TABLE subzones (
    subzone_id INT PRIMARY KEY AUTO_INCREMENT,
    subzone_name VARCHAR(100) NOT NULL,
    planning_area_id INT NOT NULL,
    FOREIGN KEY (planning_area_id) REFERENCES planning_areas(planning_area_id),
    UNIQUE KEY unique_subzone_per_area (subzone_name, planning_area_id)
);

CREATE TABLE dwelling_types (
    dwelling_type_id INT PRIMARY KEY AUTO_INCREMENT,
    dwelling_type_name VARCHAR(100) NOT NULL UNIQUE,
    category_id INT NOT NULL,
    FOREIGN KEY (category_id) REFERENCES dwelling_categories(category_id)
);

CREATE TABLE transportation_statistics (
    planning_area_id INT NOT NULL,
    transport_mode_id INT NOT NULL,
    resident_count INT NOT NULL DEFAULT 0,
    PRIMARY KEY (planning_area_id, transport_mode_id),
    FOREIGN KEY (planning_area_id) REFERENCES planning_areas(planning_area_id),
    FOREIGN KEY (transport_mode_id) REFERENCES transportation_modes(transport_mode_id)
);

CREATE TABLE population_statistics (
    subzone_id INT NOT NULL,
    dwelling_type_id INT NOT NULL,
    population_count INT NOT NULL DEFAULT 0,
    PRIMARY KEY (subzone_id, dwelling_type_id),
    FOREIGN KEY (subzone_id) REFERENCES subzones(subzone_id),
    FOREIGN KEY (dwelling_type_id) REFERENCES dwelling_types(dwelling_type_id)
);

CREATE TABLE employment_statistics (
    planning_area_id INT NOT NULL,
    occupation_id INT NOT NULL,
    employee_count INT NOT NULL DEFAULT 0,
    PRIMARY KEY (planning_area_id, occupation_id),
    FOREIGN KEY (planning_area_id) REFERENCES planning_areas(planning_area_id),
    FOREIGN KEY (occupation_id) REFERENCES occupation_categories(occupation_id)
);