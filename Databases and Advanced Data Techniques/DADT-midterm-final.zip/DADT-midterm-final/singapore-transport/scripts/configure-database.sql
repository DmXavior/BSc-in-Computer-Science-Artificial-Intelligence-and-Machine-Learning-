-- Create the database
CREATE DATABASE IF NOT EXISTS singapore_transport_db;

-- Use the database
USE singapore_transport_db;

-- Create user for project
CREATE USER IF NOT EXISTS 'singapore_user'@'localhost' IDENTIFIED BY 'transport123';
CREATE USER IF NOT EXISTS'singapore_user'@'127.0.0.1' IDENTIFIED BY 'your_password';

-- Grant all privileges on database to user
GRANT ALL PRIVILEGES ON singapore_transport_db.* TO 'singapore_user'@'localhost';
GRANT ALL PRIVILEGES ON singapore_transport_db.* TO 'singapore_user'@'127.0.0.1';

-- Flush privileges
FLUSH PRIVILEGES;

-- Show Existing Databases
SHOW DATABASES;
SELECT user, host FROM mysql.user WHERE user = 'singapore_user';
