-- ============================================================================
-- DATABASE SETUP
-- ============================================================================

-- 1. DELETE CHILD TABLES FIRST (in dependency order)
DELETE FROM population_statistics;
DELETE FROM transportation_statistics;
DELETE FROM employment_statistics;
DELETE FROM subzones;

-- 2. THEN DELETE PARENT TABLES  
DELETE FROM planning_areas;
DELETE FROM transportation_modes;
DELETE FROM dwelling_types;
DELETE FROM dwelling_categories;
DELETE FROM occupation_categories;

-- 3. RESET AUTO-INCREMENT COUNTERS
ALTER TABLE planning_areas AUTO_INCREMENT = 1;
ALTER TABLE transportation_modes AUTO_INCREMENT = 1;
ALTER TABLE dwelling_categories AUTO_INCREMENT = 1;
ALTER TABLE dwelling_types AUTO_INCREMENT = 1;
ALTER TABLE occupation_categories AUTO_INCREMENT = 1;
ALTER TABLE subzones AUTO_INCREMENT = 1;

-- 4. POPULATE PLANNING AREAS
INSERT INTO planning_areas (planning_area_name)
SELECT DISTINCT planning_areas 
FROM raw_transportation 
WHERE planning_areas != 'transportation_total_by_mode'
ORDER BY planning_areas;

-- 5. POPULATE TRANSPORTATION MODES
INSERT INTO transportation_modes (transport_mode_name, transport_category) VALUES
('Total', 'Summary'),
('Public Bus Only', 'Public'),
('MRT/LRT Only', 'Public'),
('MRT/LRT + Public Bus Only', 'Public'),
('Other Combinations of MRT/LRT or Public Bus', 'Public'),
('Taxi/Private Hire Car Only', 'Private'),
('Car Only', 'Private'),
('Private Chartered Bus/Van Only', 'Private'),
('Lorry/Pickup Only', 'Private'),
('Motorcycle/Scooter Only', 'Private'),
('Transportation Others', 'Other'),
('No Transport Required', 'None');

-- 6. POPULATE DWELLING CATEGORIES
INSERT INTO dwelling_categories (category_name, category_description) VALUES
('HDB', 'Housing Development Board flats'),
('Private', 'Private housing including condominiums'),
('Landed', 'Landed properties'),
('Others', 'Other dwelling types');

-- 7. POPULATE DWELLING TYPES
INSERT INTO dwelling_types (dwelling_type_name, category_id) 
SELECT 'HDB Dwellings Total', category_id FROM dwelling_categories WHERE category_name = 'HDB'
UNION ALL
SELECT 'HDB 1 and 2 Room Flats', category_id FROM dwelling_categories WHERE category_name = 'HDB'
UNION ALL
SELECT 'HDB 3 Room Flats', category_id FROM dwelling_categories WHERE category_name = 'HDB'
UNION ALL
SELECT 'HDB 4 Room Flats', category_id FROM dwelling_categories WHERE category_name = 'HDB'
UNION ALL
SELECT 'HDB 5 Room and Executive Flats', category_id FROM dwelling_categories WHERE category_name = 'HDB'
UNION ALL
SELECT 'Condominiums and Other Apartments', category_id FROM dwelling_categories WHERE category_name = 'Private'
UNION ALL
SELECT 'Landed Properties', category_id FROM dwelling_categories WHERE category_name = 'Landed'
UNION ALL
SELECT 'Dwellings Others', category_id FROM dwelling_categories WHERE category_name = 'Others';

-- 8. POPULATE OCCUPATION CATEGORIES
INSERT INTO occupation_categories (occupation_name, occupation_level) VALUES
('Total', 'Summary'),
('Legislators, Senior Officials and Managers', 'Senior Management'),
('Professionals', 'Professional'),
('Associate Professionals and Technicians', 'Professional'),
('Clerical Support Workers', 'Service & Support'),
('Service and Sales Workers', 'Service & Support'),
('Craftsmen and Related Trades Workers', 'Technical & Operations'),
('Plant and Machine Operators and Assemblers', 'Technical & Operations'),
('Cleaners, Labourers and Related Workers', 'Technical & Operations'),
('Occupation Others', 'Others');

-- 9. LOAD CLEAN SUBZONE MAPPINGS FROM PYTHON-PROCESSED CSV
-- Create temporary table for clean mappings
DROP TABLE IF EXISTS temp_subzone_mappings;
CREATE TEMPORARY TABLE temp_subzone_mappings (
    subzone_name VARCHAR(150),
    planning_area_name VARCHAR(100)
);

-- Load the clean CSV file
LOAD DATA INFILE '/home/coder/project/mid-term/singapore-transport/data/clean_population_by_dwelling.csv'
INTO TABLE temp_subzone_mappings
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(subzone_name, planning_area_name);

-- Insert subzones with proper planning_area_id
INSERT INTO subzones (subzone_name, planning_area_id)
SELECT 
    tsm.subzone_name,
    pa.planning_area_id
FROM temp_subzone_mappings tsm
JOIN planning_areas pa ON tsm.planning_area_name = pa.planning_area_name;

-- Clean up temporary table
DROP TEMPORARY TABLE temp_subzone_mappings;

-- 10. PIVOT TRANSPORTATION DATA
INSERT INTO transportation_statistics (planning_area_id, transport_mode_id, resident_count)
SELECT 
    pa.planning_area_id,
    tm.transport_mode_id,
    CASE tm.transport_mode_name
        WHEN 'Total' THEN rt.transportation_total_by_area
        WHEN 'Public Bus Only' THEN rt.public_bus_only
        WHEN 'MRT/LRT Only' THEN rt.mrt_lrt_only
        WHEN 'MRT/LRT + Public Bus Only' THEN rt.mrt_lrt_public_bus_only
        WHEN 'Other Combinations of MRT/LRT or Public Bus' THEN rt.other_combinations_of_mrt_lrt_or_public_bus
        WHEN 'Taxi/Private Hire Car Only' THEN rt.taxi_private_hire_car_only
        WHEN 'Car Only' THEN rt.car_only
        WHEN 'Private Chartered Bus/Van Only' THEN rt.private_chartered_bus_van_only
        WHEN 'Lorry/Pickup Only' THEN rt.lorry_pickup_only
        WHEN 'Motorcycle/Scooter Only' THEN rt.motorcycle_scooter_only
        WHEN 'Transportation Others' THEN rt.transportation_others
        WHEN 'No Transport Required' THEN rt.no_transport_required
    END as resident_count
FROM raw_transportation rt
JOIN planning_areas pa ON rt.planning_areas = pa.planning_area_name
CROSS JOIN transportation_modes tm
WHERE rt.planning_areas != 'transportation_total_by_mode';

-- 11. PIVOT POPULATION DATA
INSERT INTO population_statistics (subzone_id, dwelling_type_id, population_count)
SELECT 
    s.subzone_id,
    dt.dwelling_type_id,
    CASE dt.dwelling_type_name
        WHEN 'HDB Dwellings Total' THEN rp.hdb_dwellings_total
        WHEN 'HDB 1 and 2 Room Flats' THEN rp.hdb_dwellings_1_and_2_room_flats
        WHEN 'HDB 3 Room Flats' THEN rp.hdb_dwellings_3_room_flats
        WHEN 'HDB 4 Room Flats' THEN rp.hdb_dwellings_4_room_flats
        WHEN 'HDB 5 Room and Executive Flats' THEN rp.hdb_dwellings_5_room_and_executive_flats
        WHEN 'Condominiums and Other Apartments' THEN rp.condominiums_and_other_apartments
        WHEN 'Landed Properties' THEN rp.landed_properties
        WHEN 'Dwellings Others' THEN rp.dwellings_others
    END as population_count
FROM raw_population rp
JOIN subzones s ON rp.planning_areas = s.subzone_name
CROSS JOIN dwelling_types dt
WHERE rp.planning_areas != 'poulation_total_by_dwelling'
AND rp.planning_areas NOT LIKE '%Total';

-- 12. PIVOT EMPLOYMENT DATA
INSERT INTO employment_statistics (planning_area_id, occupation_id, employee_count)
SELECT 
    pa.planning_area_id,
    oc.occupation_id,
    CASE oc.occupation_name
        WHEN 'Total' THEN re.employment_total_by_workplace_area
        WHEN 'Legislators, Senior Officials and Managers' THEN re.legislators_senior_officials_and_managers
        WHEN 'Professionals' THEN re.professionals
        WHEN 'Associate Professionals and Technicians' THEN re.associate_professionals_and_technicians
        WHEN 'Clerical Support Workers' THEN re.clerical_support_workers
        WHEN 'Service and Sales Workers' THEN re.service_and_sales_workers
        WHEN 'Craftsmen and Related Trades Workers' THEN re.craftsmen_and_related_trades_workers
        WHEN 'Plant and Machine Operators and Assemblers' THEN re.plant_and_machine_operators_and_assemblers
        WHEN 'Cleaners, Labourers and Related Workers' THEN re.cleaners_labourers_and_related_workers
        WHEN 'Occupation Others' THEN re.occupation_others
    END as employee_count
FROM raw_employment re
JOIN planning_areas pa ON re.planning_areas = pa.planning_area_name
CROSS JOIN occupation_categories oc
WHERE re.planning_areas != 'employment_total_by_occupation';

-- ============================================================================
-- QUERIES
-- ============================================================================

-- REASEARCH QN 1
-- 1A - Transportation mode preferences by planning area (raw)
SELECT 
    pa.planning_area_name,
    tm.transport_mode_name,
    ts.resident_count
FROM transportation_statistics ts
JOIN planning_areas pa ON ts.planning_area_id = pa.planning_area_id
JOIN transportation_modes tm ON ts.transport_mode_id = tm.transport_mode_id
WHERE tm.transport_mode_name != 'Total'
ORDER BY pa.planning_area_name, ts.resident_count DESC;

-- 1B - Top 3 transportation modes by planning area
WITH ranked_transport AS (
    SELECT 
        pa.planning_area_name,
        tm.transport_mode_name,
        ts.resident_count,
        ROW_NUMBER() OVER (PARTITION BY pa.planning_area_name ORDER BY ts.resident_count DESC) as rank_num
    FROM transportation_statistics ts
    JOIN planning_areas pa ON ts.planning_area_id = pa.planning_area_id
    JOIN transportation_modes tm ON ts.transport_mode_id = tm.transport_mode_id
    WHERE tm.transport_mode_name != 'Total'
)
SELECT planning_area_name, transport_mode_name, resident_count
FROM ranked_transport 
WHERE rank_num <= 3
ORDER BY planning_area_name, rank_num;

-- 1C - Transportation mode percentages by planning area
SELECT 
    pa.planning_area_name,
    tm.transport_mode_name,
    ts.resident_count,
    total_stats.total_residents,
    ROUND((ts.resident_count * 100.0 / total_stats.total_residents), 2) as percentage
FROM transportation_statistics ts
JOIN planning_areas pa ON ts.planning_area_id = pa.planning_area_id
JOIN transportation_modes tm ON ts.transport_mode_id = tm.transport_mode_id
JOIN (
    SELECT 
        pa2.planning_area_id,
        ts2.resident_count as total_residents
    FROM transportation_statistics ts2
    JOIN planning_areas pa2 ON ts2.planning_area_id = pa2.planning_area_id
    JOIN transportation_modes tm2 ON ts2.transport_mode_id = tm2.transport_mode_id
    WHERE tm2.transport_mode_name = 'Total'
) total_stats ON pa.planning_area_id = total_stats.planning_area_id
WHERE tm.transport_mode_name != 'Total'
ORDER BY pa.planning_area_name, percentage DESC;

-- 1D - Public vs Private transport preferences by area
SELECT 
    pa.planning_area_name,
    SUM(CASE WHEN tm.transport_category = 'Public' THEN ts.resident_count ELSE 0 END) as public_transport,
    SUM(CASE WHEN tm.transport_category = 'Private' THEN ts.resident_count ELSE 0 END) as private_transport,
    SUM(CASE WHEN tm.transport_category = 'None' THEN ts.resident_count ELSE 0 END) as no_transport,
    ROUND(
        SUM(CASE WHEN tm.transport_category = 'Public' THEN ts.resident_count ELSE 0 END) * 100.0 / 
        SUM(CASE WHEN tm.transport_category IN ('Public', 'Private') THEN ts.resident_count ELSE 0 END), 2
    ) as public_transport_percentage
FROM transportation_statistics ts
JOIN planning_areas pa ON ts.planning_area_id = pa.planning_area_id
JOIN transportation_modes tm ON ts.transport_mode_id = tm.transport_mode_id
WHERE tm.transport_mode_name != 'Total'
GROUP BY pa.planning_area_id, pa.planning_area_name
ORDER BY public_transport_percentage DESC;

-- RESEARCH QN 2
-- 2A - Housing composition by planning area (subzones)
SELECT 
    pa.planning_area_name,
    dc.category_name as dwelling_category,
    SUM(ps.population_count) as total_population
FROM population_statistics ps
JOIN subzones s ON ps.subzone_id = s.subzone_id
JOIN planning_areas pa ON s.planning_area_id = pa.planning_area_id
JOIN dwelling_types dt ON ps.dwelling_type_id = dt.dwelling_type_id
JOIN dwelling_categories dc ON dt.category_id = dc.category_id
GROUP BY pa.planning_area_id, pa.planning_area_name, dc.category_id, dc.category_name
ORDER BY pa.planning_area_name, total_population DESC;

-- 2B - HDB vs Private housing and car ownership correlation
WITH housing_summary AS (
    SELECT 
        pa.planning_area_id,
        pa.planning_area_name,
        SUM(CASE WHEN dc.category_name = 'HDB' THEN ps.population_count ELSE 0 END) as hdb_population,
        SUM(CASE WHEN dc.category_name = 'Private' THEN ps.population_count ELSE 0 END) as private_population,
        SUM(ps.population_count) as total_population
    FROM population_statistics ps
    JOIN subzones s ON ps.subzone_id = s.subzone_id
    JOIN planning_areas pa ON s.planning_area_id = pa.planning_area_id
    JOIN dwelling_types dt ON ps.dwelling_type_id = dt.dwelling_type_id
    JOIN dwelling_categories dc ON dt.category_id = dc.category_id
    WHERE dc.category_name IN ('HDB', 'Private')
    GROUP BY pa.planning_area_id, pa.planning_area_name
),
transport_summary AS (
    SELECT 
        pa.planning_area_id,
        ts.resident_count as car_users
    FROM transportation_statistics ts
    JOIN planning_areas pa ON ts.planning_area_id = pa.planning_area_id
    JOIN transportation_modes tm ON ts.transport_mode_id = tm.transport_mode_id
    WHERE tm.transport_mode_name = 'Car Only'
)
SELECT 
    hs.planning_area_name,
    hs.hdb_population,
    hs.private_population,
    ROUND((hs.private_population * 100.0 / hs.total_population), 2) as private_housing_percentage,
    ts.car_users,
    ROUND((ts.car_users * 100.0 / hs.total_population), 2) as car_usage_percentage
FROM housing_summary hs
LEFT JOIN transport_summary ts ON hs.planning_area_id = ts.planning_area_id
WHERE hs.total_population > 0
ORDER BY private_housing_percentage DESC;

-- 2C - Residential density and transport patterns
WITH subzone_density AS (
    SELECT 
        s.subzone_id,
        s.subzone_name,
        pa.planning_area_name,
        SUM(ps.population_count) as subzone_population,
        CASE 
            WHEN SUM(ps.population_count) > 30000 THEN 'High Density'
            WHEN SUM(ps.population_count) > 15000 THEN 'Medium Density'
            ELSE 'Low Density'
        END as density_category
    FROM population_statistics ps
    JOIN subzones s ON ps.subzone_id = s.subzone_id
    JOIN planning_areas pa ON s.planning_area_id = pa.planning_area_id
    GROUP BY s.subzone_id, s.subzone_name, pa.planning_area_name
)
SELECT 
    sd.density_category,
    COUNT(DISTINCT sd.subzone_id) as subzone_count,
    AVG(sd.subzone_population) as avg_population_per_subzone
FROM subzone_density sd
GROUP BY sd.density_category
ORDER BY avg_population_per_subzone DESC;

-- RESEARCH QN 3
-- 3A - Employment distribution by workplace planning area and occupation
SELECT 
    pa.planning_area_name,
    oc.occupation_name,
    es.employee_count
FROM employment_statistics es
JOIN planning_areas pa ON es.planning_area_id = pa.planning_area_id
JOIN occupation_categories oc ON es.occupation_id = oc.occupation_id
WHERE oc.occupation_name != 'Total'
ORDER BY pa.planning_area_name, es.employee_count DESC;

-- 3B - Top employment center area
SELECT 
    pa.planning_area_name,
    es.employee_count as total_employees
FROM employment_statistics es
JOIN planning_areas pa ON es.planning_area_id = pa.planning_area_id
JOIN occupation_categories oc ON es.occupation_id = oc.occupation_id
WHERE oc.occupation_name = 'Total'
ORDER BY es.employee_count DESC
LIMIT 10;

-- 3C - Professional vs Service occupation distribution by workplace
WITH occupation_summary AS (
    SELECT 
        pa.planning_area_id,
        pa.planning_area_name,
        SUM(CASE WHEN oc.occupation_level = 'Professional' THEN es.employee_count ELSE 0 END) as professional_jobs,
        SUM(CASE WHEN oc.occupation_level = 'Service & Support' THEN es.employee_count ELSE 0 END) as service_jobs,
        SUM(CASE WHEN oc.occupation_level = 'Senior Management' THEN es.employee_count ELSE 0 END) as management_jobs,
        SUM(CASE WHEN oc.occupation_name != 'Total' THEN es.employee_count ELSE 0 END) as total_jobs
    FROM employment_statistics es
    JOIN planning_areas pa ON es.planning_area_id = pa.planning_area_id
    JOIN occupation_categories oc ON es.occupation_id = oc.occupation_id
    WHERE oc.occupation_name != 'Total'
    GROUP BY pa.planning_area_id, pa.planning_area_name
)
SELECT 
    planning_area_name,
    professional_jobs,
    service_jobs,
    management_jobs,
    total_jobs,
    ROUND((professional_jobs * 100.0 / total_jobs), 2) as professional_percentage,
    ROUND((management_jobs * 100.0 / total_jobs), 2) as management_percentage
FROM occupation_summary
WHERE total_jobs > 1000
ORDER BY professional_percentage DESC;

-- 3D - Transportation demand estimation for major employment center areas
SELECT 
    pa.planning_area_name,
    emp.employee_count as total_employees,
    ROUND((emp.employee_count * 0.85), 0) as estimated_daily_commuters,
    CASE 
        WHEN emp.employee_count > 100000 THEN 'Major Employment Hub'
        WHEN emp.employee_count > 50000 THEN 'Significant Employment Center'
        WHEN emp.employee_count > 20000 THEN 'Medium Employment Area'
        ELSE 'Small Employment Area'
    END as employment_classification
FROM employment_statistics emp
JOIN planning_areas pa ON emp.planning_area_id = pa.planning_area_id
JOIN occupation_categories oc ON emp.occupation_id = oc.occupation_id
WHERE oc.occupation_name = 'Total'
ORDER BY emp.employee_count DESC;

-- BONUS QNS
-- 4A - Comprehensive Urban Profile by Planning Area
WITH residential_profile AS (
    -- WHERE PEOPLE LIVE: Housing composition by planning area
    SELECT 
        pa.planning_area_id,
        pa.planning_area_name,
        SUM(CASE WHEN dc.category_name = 'HDB' THEN ps.population_count ELSE 0 END) as hdb_residents,
        SUM(CASE WHEN dc.category_name = 'Private' THEN ps.population_count ELSE 0 END) as private_residents,
        SUM(CASE WHEN dc.category_name = 'Landed' THEN ps.population_count ELSE 0 END) as landed_residents,
        SUM(ps.population_count) as total_residents,
        ROUND(SUM(CASE WHEN dc.category_name = 'Private' THEN ps.population_count ELSE 0 END) * 100.0 / 
              NULLIF(SUM(ps.population_count), 0), 2) as private_housing_percentage
    FROM population_statistics ps
    JOIN subzones s ON ps.subzone_id = s.subzone_id
    JOIN planning_areas pa ON s.planning_area_id = pa.planning_area_id
    JOIN dwelling_types dt ON ps.dwelling_type_id = dt.dwelling_type_id
    JOIN dwelling_categories dc ON dt.category_id = dc.category_id
    GROUP BY pa.planning_area_id, pa.planning_area_name
),
transportation_profile AS (
    -- HOW PEOPLE TRAVEL: Transportation patterns from residential areas
    SELECT 
        pa.planning_area_id,
        SUM(CASE WHEN tm.transport_mode_name = 'Car Only' THEN ts.resident_count ELSE 0 END) as car_commuters,
        SUM(CASE WHEN tm.transport_category = 'Public' THEN ts.resident_count ELSE 0 END) as public_transport_users,
        SUM(CASE WHEN tm.transport_mode_name = 'Total' THEN ts.resident_count ELSE 0 END) as total_commuters,
        ROUND(SUM(CASE WHEN tm.transport_mode_name = 'Car Only' THEN ts.resident_count ELSE 0 END) * 100.0 / 
              NULLIF(SUM(CASE WHEN tm.transport_mode_name = 'Total' THEN ts.resident_count ELSE 0 END), 0), 2) as car_usage_percentage
    FROM transportation_statistics ts
    JOIN planning_areas pa ON ts.planning_area_id = pa.planning_area_id
    JOIN transportation_modes tm ON ts.transport_mode_id = tm.transport_mode_id
    GROUP BY pa.planning_area_id
),
employment_profile AS (
    -- WHERE PEOPLE WORK: Employment patterns by workplace areas
    SELECT 
        pa.planning_area_id,
        SUM(CASE WHEN oc.occupation_level = 'Professional' THEN es.employee_count ELSE 0 END) as professional_jobs,
        SUM(CASE WHEN oc.occupation_level = 'Senior Management' THEN es.employee_count ELSE 0 END) as management_jobs,
        SUM(CASE WHEN oc.occupation_level = 'Service & Support' THEN es.employee_count ELSE 0 END) as service_jobs,
        SUM(CASE WHEN oc.occupation_name = 'Total' THEN es.employee_count ELSE 0 END) as total_jobs,
        ROUND(SUM(CASE WHEN oc.occupation_level IN ('Professional', 'Senior Management') THEN es.employee_count ELSE 0 END) * 100.0 / 
              NULLIF(SUM(CASE WHEN oc.occupation_name != 'Total' THEN es.employee_count ELSE 0 END), 0), 2) as high_skill_job_percentage
    FROM employment_statistics es
    JOIN planning_areas pa ON es.planning_area_id = pa.planning_area_id
    JOIN occupation_categories oc ON es.occupation_id = oc.occupation_id
    GROUP BY pa.planning_area_id
)
SELECT 
    rp.planning_area_name,
    -- RESIDENTIAL PROFILE
    rp.total_residents,
    rp.private_housing_percentage,
    -- TRANSPORTATION PROFILE  
    tp.car_usage_percentage,
    tp.public_transport_users,
    -- EMPLOYMENT PROFILE
    ep.total_jobs,
    ep.high_skill_job_percentage,
    -- INTEGRATED INSIGHTS
    CASE 
        WHEN rp.private_housing_percentage > 50 AND tp.car_usage_percentage > 25 THEN 'Affluent Car-Dependent Area'
        WHEN rp.private_housing_percentage > 30 AND ep.high_skill_job_percentage > 60 THEN 'Professional Business District'
        WHEN rp.total_residents > 100000 AND tp.car_usage_percentage < 15 THEN 'High-Density Public Transport Hub'
        WHEN ep.total_jobs > 50000 AND ep.high_skill_job_percentage > 50 THEN 'Major Professional Employment Center'
        WHEN rp.private_housing_percentage < 20 AND tp.car_usage_percentage < 20 THEN 'HDB-Dominated Public Transport Area'
        ELSE 'Mixed Development Area'
    END as area_classification,
    -- JOBS-TO-RESIDENTS RATIO (Economic activity indicator)
    ROUND(COALESCE(ep.total_jobs, 0) * 1.0 / NULLIF(rp.total_residents, 0), 2) as jobs_to_residents_ratio
FROM residential_profile rp
LEFT JOIN transportation_profile tp ON rp.planning_area_id = tp.planning_area_id
LEFT JOIN employment_profile ep ON rp.planning_area_id = ep.planning_area_id
WHERE rp.total_residents > 0
ORDER BY jobs_to_residents_ratio DESC;

-- 4B - Do areas with more professional jobs have different commuting patterns
WITH workplace_analysis AS (
    SELECT 
        pa.planning_area_name,
        SUM(CASE WHEN oc.occupation_level = 'Professional' THEN es.employee_count ELSE 0 END) as professional_jobs,
        SUM(CASE WHEN oc.occupation_name = 'Total' THEN es.employee_count ELSE 0 END) as total_jobs
    FROM employment_statistics es
    JOIN planning_areas pa ON es.planning_area_id = pa.planning_area_id
    JOIN occupation_categories oc ON es.occupation_id = oc.occupation_id
    GROUP BY pa.planning_area_id, pa.planning_area_name
),
transport_from_area AS (
    SELECT 
        pa.planning_area_name,
        SUM(CASE WHEN tm.transport_mode_name = 'Car Only' THEN ts.resident_count ELSE 0 END) as car_users,
        SUM(CASE WHEN tm.transport_mode_name = 'Total' THEN ts.resident_count ELSE 0 END) as total_commuters
    FROM transportation_statistics ts
    JOIN planning_areas pa ON ts.planning_area_id = pa.planning_area_id
    JOIN transportation_modes tm ON ts.transport_mode_id = tm.transport_mode_id
    GROUP BY pa.planning_area_id, pa.planning_area_name
)
SELECT 
    wa.planning_area_name,
    wa.professional_jobs,
    wa.total_jobs,
    ROUND(wa.professional_jobs * 100.0 / NULLIF(wa.total_jobs, 0), 2) as professional_job_percentage,
    tfa.car_users,
    tfa.total_commuters,
    ROUND(tfa.car_users * 100.0 / NULLIF(tfa.total_commuters, 0), 2) as car_usage_percentage,
    -- CORRELATION INSIGHT
    CASE 
        WHEN wa.professional_jobs > 10000 AND tfa.car_users * 100.0 / NULLIF(tfa.total_commuters, 0) > 20 
        THEN 'High Professional Jobs + High Car Usage'
        WHEN wa.professional_jobs > 10000 AND tfa.car_users * 100.0 / NULLIF(tfa.total_commuters, 0) < 15 
        THEN 'High Professional Jobs + Public Transport Oriented'
        ELSE 'Mixed Pattern'
    END as transport_employment_pattern
FROM workplace_analysis wa
LEFT JOIN transport_from_area tfa ON wa.planning_area_name = tfa.planning_area_name
WHERE wa.total_jobs > 1000
ORDER BY professional_job_percentage DESC;

-- 4C - Overall lifestyle pattern
SELECT 
    pa.planning_area_name,
    
    -- HOUSING DIMENSION (WHERE THEY LIVE)
    CASE 
        WHEN SUM(CASE WHEN dc.category_name = 'Private' THEN ps.population_count ELSE 0 END) * 100.0 / 
             NULLIF(SUM(ps.population_count), 0) > 50 THEN 'Private Housing Dominant'
        WHEN SUM(CASE WHEN dc.category_name = 'HDB' THEN ps.population_count ELSE 0 END) * 100.0 / 
             NULLIF(SUM(ps.population_count), 0) > 80 THEN 'HDB Dominant'
        ELSE 'Mixed Housing'
    END as housing_profile,
    
    -- TRANSPORTATION DIMENSION (HOW THEY TRAVEL)
    CASE 
        WHEN SUM(CASE WHEN tm.transport_mode_name = 'Car Only' THEN ts.resident_count ELSE 0 END) * 100.0 / 
             NULLIF(SUM(CASE WHEN tm.transport_mode_name = 'Total' THEN ts.resident_count ELSE 0 END), 0) > 25 THEN 'Car Oriented'
        WHEN SUM(CASE WHEN tm.transport_category = 'Public' THEN ts.resident_count ELSE 0 END) * 100.0 / 
             NULLIF(SUM(CASE WHEN tm.transport_mode_name = 'Total' THEN ts.resident_count ELSE 0 END), 0) > 70 THEN 'Public Transport Oriented'
        ELSE 'Mixed Transport'
    END as transport_profile,
    
    -- EMPLOYMENT DIMENSION (WHAT JOBS ARE HERE)
    CASE 
        WHEN SUM(CASE WHEN oc.occupation_level IN ('Professional', 'Senior Management') THEN es.employee_count ELSE 0 END) * 100.0 / 
             NULLIF(SUM(CASE WHEN oc.occupation_name != 'Total' THEN es.employee_count ELSE 0 END), 0) > 60 THEN 'Professional Hub'
        WHEN SUM(CASE WHEN oc.occupation_level = 'Service & Support' THEN es.employee_count ELSE 0 END) * 100.0 / 
             NULLIF(SUM(CASE WHEN oc.occupation_name != 'Total' THEN es.employee_count ELSE 0 END), 0) > 50 THEN 'Service Center'
        ELSE 'Mixed Employment'
    END as employment_profile,
    
    -- INTEGRATED LIFESTYLE CLASSIFICATION
    CONCAT(
        CASE 
            WHEN SUM(CASE WHEN dc.category_name = 'Private' THEN ps.population_count ELSE 0 END) * 100.0 / 
                 NULLIF(SUM(ps.population_count), 0) > 50 THEN 'Upscale-'
            ELSE 'Mass-'
        END,
        CASE 
            WHEN SUM(CASE WHEN tm.transport_mode_name = 'Car Only' THEN ts.resident_count ELSE 0 END) * 100.0 / 
                 NULLIF(SUM(CASE WHEN tm.transport_mode_name = 'Total' THEN ts.resident_count ELSE 0 END), 0) > 25 THEN 'Car-'
            ELSE 'Transit-'
        END,
        CASE 
            WHEN SUM(CASE WHEN oc.occupation_level IN ('Professional', 'Senior Management') THEN es.employee_count ELSE 0 END) * 100.0 / 
                 NULLIF(SUM(CASE WHEN oc.occupation_name != 'Total' THEN es.employee_count ELSE 0 END), 0) > 60 THEN 'Professional'
            ELSE 'Mixed'
        END
    ) as lifestyle_classification

FROM population_statistics ps
JOIN subzones s ON ps.subzone_id = s.subzone_id
JOIN planning_areas pa ON s.planning_area_id = pa.planning_area_id
JOIN dwelling_types dt ON ps.dwelling_type_id = dt.dwelling_type_id
JOIN dwelling_categories dc ON dt.category_id = dc.category_id
LEFT JOIN transportation_statistics ts ON pa.planning_area_id = ts.planning_area_id
LEFT JOIN transportation_modes tm ON ts.transport_mode_id = tm.transport_mode_id
LEFT JOIN employment_statistics es ON pa.planning_area_id = es.planning_area_id
LEFT JOIN occupation_categories oc ON es.occupation_id = oc.occupation_id

GROUP BY pa.planning_area_id, pa.planning_area_name
HAVING SUM(ps.population_count) > 10000  -- Focus on substantial areas
ORDER BY pa.planning_area_name;

-- 4D - Areas with high condominium populations vs transport pattern
WITH condo_areas AS (
    SELECT 
        pa.planning_area_id,
        pa.planning_area_name,
        SUM(CASE WHEN dt.dwelling_type_name = 'Condominiums and Other Apartments' 
            THEN ps.population_count ELSE 0 END) as condo_residents,
        SUM(ps.population_count) as total_residents,
        ROUND(SUM(CASE WHEN dt.dwelling_type_name = 'Condominiums and Other Apartments' 
            THEN ps.population_count ELSE 0 END) * 100.0 / SUM(ps.population_count), 2) as condo_percentage
    FROM population_statistics ps
    JOIN subzones s ON ps.subzone_id = s.subzone_id
    JOIN planning_areas pa ON s.planning_area_id = pa.planning_area_id
    JOIN dwelling_types dt ON ps.dwelling_type_id = dt.dwelling_type_id
    GROUP BY pa.planning_area_id, pa.planning_area_name
    HAVING condo_percentage > 20
)
SELECT 
    ca.planning_area_name,
    ca.condo_residents,
    ca.condo_percentage,
    tm.transport_mode_name,
    ts.resident_count
FROM condo_areas ca
JOIN transportation_statistics ts ON ca.planning_area_id = ts.planning_area_id
JOIN transportation_modes tm ON ts.transport_mode_id = tm.transport_mode_id
WHERE tm.transport_mode_name != 'Total'
ORDER BY ca.condo_percentage DESC, ts.resident_count DESC;

-- car usage percentage by condo areas
WITH condo_areas AS (
    SELECT 
        pa.planning_area_id,
        pa.planning_area_name,
        SUM(CASE WHEN dt.dwelling_type_name = 'Condominiums and Other Apartments' 
            THEN ps.population_count ELSE 0 END) as condo_residents,
        SUM(ps.population_count) as total_residents,
        ROUND(SUM(CASE WHEN dt.dwelling_type_name = 'Condominiums and Other Apartments' 
            THEN ps.population_count ELSE 0 END) * 100.0 / SUM(ps.population_count), 2) as condo_percentage
    FROM population_statistics ps
    JOIN subzones s ON ps.subzone_id = s.subzone_id
    JOIN planning_areas pa ON s.planning_area_id = pa.planning_area_id
    JOIN dwelling_types dt ON ps.dwelling_type_id = dt.dwelling_type_id
    GROUP BY pa.planning_area_id, pa.planning_area_name
    HAVING condo_percentage > 20
),
transport_summary AS (
    SELECT 
        ts.planning_area_id,
        SUM(CASE WHEN tm.transport_mode_name = 'Car Only' THEN ts.resident_count ELSE 0 END) as car_users,
        SUM(CASE WHEN tm.transport_mode_name = 'Total' THEN ts.resident_count ELSE 0 END) as total_commuters
    FROM transportation_statistics ts
    JOIN transportation_modes tm ON ts.transport_mode_id = tm.transport_mode_id
    GROUP BY ts.planning_area_id
)
SELECT 
    ca.planning_area_name,
    ca.condo_percentage,
    ts.car_users,
    ts.total_commuters,
    ROUND(ts.car_users * 100.0 / ts.total_commuters, 2) as car_usage_percentage
FROM condo_areas ca
JOIN transport_summary ts ON ca.planning_area_id = ts.planning_area_id
ORDER BY ca.condo_percentage DESC;
