DROP TABLE IF EXISTS raw_transportation;
DROP TABLE IF EXISTS raw_population; 
DROP TABLE IF EXISTS raw_employment;


CREATE TABLE raw_transportation (
    planning_areas VARCHAR(100) NOT NULL,
    transportation_total_by_area INT DEFAULT 0,
    public_bus_only INT DEFAULT 0,
    mrt_lrt_only INT DEFAULT 0,
    mrt_lrt_public_bus_only INT DEFAULT 0,
    other_combinations_of_mrt_lrt_or_public_bus INT DEFAULT 0,
    taxi_private_hire_car_only INT DEFAULT 0,
    car_only INT DEFAULT 0,
    private_chartered_bus_van_only INT DEFAULT 0,
    lorry_pickup_only INT DEFAULT 0,
    motorcycle_scooter_only INT DEFAULT 0,
    transportation_others INT DEFAULT 0,
    no_transport_required INT DEFAULT 0
    );

CREATE TABLE raw_population (
    planning_areas VARCHAR(100) NOT NULL,
    population_total_by_area INT DEFAULT 0,
    hdb_dwellings_total INT DEFAULT 0,
    hdb_dwellings_1_and_2_room_flats INT DEFAULT 0,
    hdb_dwellings_3_room_flats INT DEFAULT 0,
    hdb_dwellings_4_room_flats INT DEFAULT 0,
    hdb_dwellings_5_room_and_executive_flats INT DEFAULT 0,
    condominiums_and_other_apartments INT DEFAULT 0,
    landed_properties INT DEFAULT 0,
    dwellings_others INT DEFAULT 0
);

CREATE TABLE raw_employment (
    planning_areas VARCHAR(100) NOT NULL,
    employment_total_by_workplace_area INT DEFAULT 0,
    legislators_senior_officials_and_managers INT DEFAULT 0,
    professionals INT DEFAULT 0,
    associate_professionals_and_technicians INT DEFAULT 0,
    clerical_support_workers INT DEFAULT 0,
    service_and_sales_workers INT DEFAULT 0,
    craftsmen_and_related_trades_workers INT DEFAULT 0,
    plant_and_machine_operators_and_assemblers INT DEFAULT 0,
    cleaners_labourers_and_related_workers INT DEFAULT 0,
    occupation_others INT DEFAULT 0
);

LOAD DATA INFILE '/home/coder/project/mid-term/singapore-transport/data/transportation_by_residence.csv'
INTO TABLE raw_transportation
FIELDS TERMINATED BY ','
ENCLOSED BY ''
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA INFILE '/home/coder/project/mid-term/singapore-transport/data/population_by_dwelling.csv'
INTO TABLE raw_population
FIELDS TERMINATED BY ','
ENCLOSED BY ''
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA INFILE '/home/coder/project/mid-term/singapore-transport/data/employment_by_workplace.csv'
INTO TABLE raw_employment
FIELDS TERMINATED BY ','
ENCLOSED BY ''
LINES TERMINATED BY '\n'
IGNORE 1 LINES;